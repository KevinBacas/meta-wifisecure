#undef andn
#define andn 0
#include "nonstd.c"
